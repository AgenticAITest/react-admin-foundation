# Module Sandbox Template

A turnkey development environment for creating business modules using clean plugin architecture.

## 🚀 Quick Start

1. **Install Dependencies:**
   ```bash
   npm install
   ```

2. **Configure Environment:**
   ```bash
   cp .env.example .env
   # Edit .env with your DATABASE_URL
   ```

3. **Initialize Database:**
   ```bash
   npm run db:push
   ```

4. **Start Development:**
   ```bash
   npm run dev
   ```

5. **Access Your Module:**
   - Frontend: http://localhost:5173
   - API Health: http://localhost:8787/api/plugins/sample/health

## 📁 Project Structure

```
├── server/index.ts         # 🎯 YOUR MAIN FOCUS - Plugin business logic
├── sandbox/               # Infrastructure (managed automatically)
├── client/src/            # React frontend components
├── shared/schema.ts       # Database schema (no tenantId needed)
├── vite.config.ts        # Vite proxy configuration
└── .env.example          # Environment variables template
```

## 🔧 Development Workflow

### 1. Customize Your Module
- **Module ID**: Update `MODULE_ID` in `server/index.ts`
- **Database Schema**: Add tables in `shared/schema.ts`
- **Business Logic**: Implement CRUD operations in `server/index.ts`
- **UI Components**: Customize `client/src/main.tsx`

### 2. Plugin Pattern
```typescript
// server/index.ts
const plugin = {
  meta: { id: 'your-module', version: '0.1.0', api: '1.x' },
  
  async register(ctx: PluginContext) {
    // Use ctx.router, ctx.rbac, ctx.withTenantTx, ctx.log
    ctx.router.get('/items', ctx.rbac.require('your-module.items.read'), async (req: any, res) => {
      const rows = await ctx.withTenantTx(req.auth?.tenant_id, async (db) => {
        const r = await db.execute('select * from items order by created_at desc');
        return (r as any).rows ?? r;
      });
      res.json(rows);
    });
  },
};

export const permissions = ['your-module.items.read', 'your-module.items.create'];
export default plugin;
```

### 3. Schema-per-Tenant
```typescript
// shared/schema.ts - NO tenantId column needed
export const items = pgTable('items', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  name: varchar('name', { length: 255 }).notNull(),
  created_at: timestamp('created_at').defaultNow().notNull(),
});
```

## ✅ Verification Checklist

- [ ] `GET /api/plugins/sample/health` returns `200 { ok: true }`
- [ ] Database creates `tenant_dev` schema and `items` table
- [ ] `GET /api/plugins/sample/items` returns `200` (with permissions)
- [ ] React frontend loads and can add/list items
- [ ] No `tenantId` columns in tenant schema tables

## 📖 Full Documentation

See the complete setup guide: [Module Sandbox Setup](./docs/module-sandbox-setup.md)

## 🏗️ Integration to Foundation

When ready, copy your plugin to the main application:
```bash
cp server/index.ts ../foundation/src/modules/your-module/
cp -r client/src/ ../foundation/src/client/modules/your-module/
cp shared/schema.ts ../foundation/src/modules/your-module/schema.ts
```

---

**Ready to build your module?** Start with `npm run dev` and focus on `server/index.ts`!