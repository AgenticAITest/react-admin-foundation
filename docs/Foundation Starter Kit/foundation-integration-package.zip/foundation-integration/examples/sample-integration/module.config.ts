// Sample module configuration for foundation
export default {
  id: 'sample',
  name: 'Sample Module',
  version: '1.0.0',
  api: '1.x',
  permissions: [
    'sample.items.read',
    'sample.items.create',
    'sample.items.update', 
    'sample.items.delete'
  ],
  nav: {
    basePath: '/app/sample',
    items: [
      { 
        path: '/app/sample/items', 
        label: 'Items', 
        icon: 'List',
        permissions: ['sample.items.read'] 
      },
      { 
        path: '/app/sample/create', 
        label: 'Create Item', 
        icon: 'Plus',
        permissions: ['sample.items.create'] 
      }
    ]
  },
  settings: {
    enableBulkOperations: true,
    defaultPageSize: 10,
    maxFileUploadSize: '5MB'
  }
};