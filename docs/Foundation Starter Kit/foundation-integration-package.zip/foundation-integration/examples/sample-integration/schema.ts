// Sample module database schema
import { pgTable, uuid, varchar, text, timestamp, sql } from 'drizzle-orm/pg-core';

// ✅ Schema-per-tenant: NO tenantId column needed
// Isolation is handled via search_path to tenant-specific schemas
export const items = pgTable('items', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});