// Sample plugin - basic CRUD operations
// This is a complete plugin example from sandbox integration

const MODULE_ID = 'sample';

export interface PluginContext {
  router: any;
  rbac: { require: (permission: string) => any };
  withTenantTx: (tenantId: string, callback: (db: any) => Promise<any>) => Promise<any>;
  log: (message: string, meta?: object) => void;
}

const plugin = {
  meta: {
    id: MODULE_ID,
    version: '0.1.0',
    api: '1.x'
  },

  async register(ctx: PluginContext) {
    // Health check endpoint (always accessible)
    ctx.router.get('/health', async (req: any, res: any) => {
      res.json({ ok: true, plugin: MODULE_ID, version: plugin.meta.version });
    });

    // List items with pagination and filtering
    ctx.router.get('/items', ctx.rbac.require('sample.items.read'), async (req: any, res: any) => {
      try {
        const { page = '1', perPage = '10', filter = '', sort = 'name', order = 'asc' } = req.query ?? {};
        const pageNum = parseInt(page);
        const perPageNum = parseInt(perPage);
        const offset = (pageNum - 1) * perPageNum;

        const items = await ctx.withTenantTx(req.auth?.tenant_id, async (db) => {
          let query = 'SELECT * FROM items';
          let countQuery = 'SELECT COUNT(*) as total FROM items';
          const params = [];
          
          if (filter) {
            query += ' WHERE name ILIKE $1';
            countQuery += ' WHERE name ILIKE $1';
            params.push(`%${filter}%`);
          }
          
          query += ` ORDER BY ${sort} ${order} LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
          params.push(perPageNum, offset);
          
          const [itemsResult, countResult] = await Promise.all([
            db.execute(query, params),
            db.execute(countQuery, filter ? [`%${filter}%`] : [])
          ]);
          
          return {
            items: (itemsResult as any).rows ?? itemsResult,
            total: ((countResult as any).rows ?? countResult)[0].total
          };
        });

        res.json({
          items: items.items,
          total: parseInt(items.total),
          page: pageNum,
          perPage: perPageNum,
          totalPages: Math.ceil(items.total / perPageNum)
        });
      } catch (error) {
        console.error('Error fetching items:', error);
        res.status(500).json({ error: 'FETCH_FAILED' });
      }
    });

    // Create new item
    ctx.router.post('/items', ctx.rbac.require('sample.items.create'), async (req: any, res: any) => {
      try {
        const { name, description } = req.body ?? {};
        
        if (!name || !String(name).trim()) {
          return res.status(400).json({ error: 'NAME_REQUIRED' });
        }

        const item = await ctx.withTenantTx(req.auth?.tenant_id, async (db) => {
          const result = await db.execute(
            'INSERT INTO items (name, description) VALUES ($1, $2) RETURNING *',
            [name.trim(), description || null]
          );
          return ((result as any).rows ?? result)[0];
        });

        res.status(201).json(item);
        ctx.log('Item created', { itemId: item.id, name: item.name });
      } catch (error) {
        console.error('Error creating item:', error);
        res.status(500).json({ error: 'CREATE_FAILED' });
      }
    });

    // Update existing item
    ctx.router.put('/items/:id', ctx.rbac.require('sample.items.update'), async (req: any, res: any) => {
      try {
        const { id } = req.params;
        const { name, description } = req.body ?? {};

        if (!name || !String(name).trim()) {
          return res.status(400).json({ error: 'NAME_REQUIRED' });
        }

        const item = await ctx.withTenantTx(req.auth?.tenant_id, async (db) => {
          const result = await db.execute(
            'UPDATE items SET name = $1, description = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3 RETURNING *',
            [name.trim(), description || null, id]
          );
          return ((result as any).rows ?? result)[0];
        });

        if (!item) {
          return res.status(404).json({ error: 'ITEM_NOT_FOUND' });
        }

        res.json(item);
        ctx.log('Item updated', { itemId: id, name: item.name });
      } catch (error) {
        console.error('Error updating item:', error);
        res.status(500).json({ error: 'UPDATE_FAILED' });
      }
    });

    // Delete item
    ctx.router.delete('/items/:id', ctx.rbac.require('sample.items.delete'), async (req: any, res: any) => {
      try {
        const { id } = req.params;

        const deleted = await ctx.withTenantTx(req.auth?.tenant_id, async (db) => {
          const result = await db.execute(
            'DELETE FROM items WHERE id = $1 RETURNING id, name',
            [id]
          );
          return ((result as any).rows ?? result)[0];
        });

        if (!deleted) {
          return res.status(404).json({ error: 'ITEM_NOT_FOUND' });
        }

        res.json({ success: true, deleted });
        ctx.log('Item deleted', { itemId: id, name: deleted.name });
      } catch (error) {
        console.error('Error deleting item:', error);
        res.status(500).json({ error: 'DELETE_FAILED' });
      }
    });

    ctx.log('Sample plugin registered successfully');
  }
};

export const permissions = [
  'sample.items.read',
  'sample.items.create', 
  'sample.items.update',
  'sample.items.delete'
];

export default plugin;