// Foundation adapter for sample plugin
import { Router } from 'express';
import plugin, { permissions as pluginPermissions } from '../plugin';
import { withTenantTx } from '../../../lib/db/tenant-db';
import { requirePermission } from '../../../lib/security/rbac';

const router = Router();

// Create plugin context that bridges to foundation infrastructure
const ctx = {
  router,
  rbac: { 
    require: (perm: string) => requirePermission(perm) 
  },
  withTenantTx,
  log: (msg: string, meta?: object) =>
    console.log(JSON.stringify({ 
      at: 'plugin', 
      plugin: plugin.meta?.id ?? 'sample', 
      msg, 
      ...meta 
    })),
};

// Register the plugin with foundation context
plugin.register(ctx).catch(error => {
  console.error(`Failed to register plugin ${plugin.meta?.id}:`, error);
});

// Export permissions for foundation RBAC system
export const permissions = pluginPermissions;

// Export router for foundation route registry
export default router;