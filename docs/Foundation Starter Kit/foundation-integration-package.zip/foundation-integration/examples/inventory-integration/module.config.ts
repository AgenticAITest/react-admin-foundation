// Inventory module configuration - more complex example
export default {
  id: 'inventory',
  name: 'Inventory Management',
  version: '1.0.0', 
  api: '1.x',
  permissions: [
    // Product permissions
    'inventory.products.read',
    'inventory.products.create',
    'inventory.products.update',
    'inventory.products.delete',
    'inventory.products.bulk_update',
    
    // Category permissions
    'inventory.categories.read',
    'inventory.categories.create',
    'inventory.categories.update',
    'inventory.categories.delete',
    
    // Stock management
    'inventory.stock.read',
    'inventory.stock.adjust',
    'inventory.stock.transfer',
    
    // Reports and admin
    'inventory.reports.read',
    'inventory.reports.export',
    'inventory.admin'
  ],
  nav: {
    basePath: '/app/inventory',
    items: [
      { 
        path: '/app/inventory/products', 
        label: 'Products', 
        icon: 'Package',
        permissions: ['inventory.products.read']
      },
      { 
        path: '/app/inventory/categories', 
        label: 'Categories', 
        icon: 'FolderOpen',
        permissions: ['inventory.categories.read']
      },
      { 
        path: '/app/inventory/stock', 
        label: 'Stock Levels', 
        icon: 'BarChart3',
        permissions: ['inventory.stock.read']
      },
      { 
        path: '/app/inventory/reports', 
        label: 'Reports', 
        icon: 'FileText',
        permissions: ['inventory.reports.read']
      },
      {
        path: '/app/inventory/settings',
        label: 'Settings',
        icon: 'Settings',
        permissions: ['inventory.admin']
      }
    ]
  },
  settings: {
    enableBulkOperations: true,
    enableStockAlerts: true,
    lowStockThreshold: 10,
    defaultPageSize: 25,
    maxFileUploadSize: '10MB',
    allowNegativeStock: false,
    enableBarcodeScanning: true
  }
};