# Integration Examples

This directory contains complete examples of sandbox plugins integrated into the foundation application.

## Examples Included

### 1. Sample Integration (`sample-integration/`)
**Basic CRUD Example**
- Simple item management with create, read, update, delete
- Basic pagination and filtering
- Standard RBAC permissions
- Minimal configuration

**Files:**
- `server/plugin.ts` - Complete plugin implementation
- `server/routes/index.ts` - Foundation adapter
- `module.config.ts` - Basic module configuration
- `schema.ts` - Simple database schema

### 2. Inventory Integration (`inventory-integration/`)
**Complex Business Module**
- Product and category management
- Stock level tracking and adjustments
- Advanced permissions (bulk operations, reports, admin)
- Multi-level navigation structure
- Business-specific settings

**Files:**
- `module.config.ts` - Advanced configuration with multiple nav sections

### 3. Tasks Integration (`tasks-integration/`)
**Advanced Workflow Module**
- Task and project management
- Team collaboration features
- Workflow management
- Advanced reporting and analytics
- Complex permission structure
- Rich feature configuration

**Files:**
- `module.config.ts` - Complex configuration with workflow features

## Usage Instructions

### Using an Example

1. **Copy Example Structure:**
   ```bash
   # Copy desired example to your foundation
   cp -r examples/sample-integration/* ../foundation/src/modules/your-module/
   ```

2. **Customize Configuration:**
   ```typescript
   // Update module.config.ts
   export default {
     id: 'your-module-id',        // Change this
     name: 'Your Module Name',     // Change this
     // ... rest of configuration
   };
   ```

3. **Update Plugin Implementation:**
   ```typescript
   // In server/plugin.ts, update MODULE_ID
   const MODULE_ID = 'your-module-id';
   ```

4. **Integrate with Foundation:**
   - Follow the integration steps in `../integration-steps.md`
   - Test all functionality works correctly
   - Verify RBAC permissions are enforced

### Customizing Examples

Each example can be used as a starting point:

**For Simple Modules:** Use `sample-integration` as base
- Single entity CRUD operations
- Basic permissions and navigation
- Minimal configuration

**For Business Modules:** Use `inventory-integration` as base  
- Multiple related entities
- Business logic and validation
- Advanced permissions and features

**For Workflow Modules:** Use `tasks-integration` as base
- Complex entity relationships
- Advanced workflow features
- Rich permissions and settings

## Key Patterns Demonstrated

### 1. Plugin Structure
All examples follow the same plugin pattern:
```typescript
const plugin = {
  meta: { id, version, api },
  async register(ctx: PluginContext) {
    // Business logic implementation
  }
};
```

### 2. Foundation Adapter
All examples use the same adapter pattern:
```typescript
const ctx = {
  router,
  rbac: { require: foundationRBAC },
  withTenantTx: foundationTenantHelper,
  log: foundationLogger
};
await plugin.register(ctx);
```

### 3. Module Configuration
All examples define navigation and permissions:
```typescript
export default {
  id: 'module-id',
  permissions: [...],
  nav: {
    basePath: '/app/module',
    items: [...]
  }
};
```

### 4. Schema Design
All examples use schema-per-tenant pattern:
```typescript
// NO tenantId column - isolation via search_path
export const entities = pgTable('entities', {
  id: uuid('id').primaryKey(),
  // ... other columns
});
```

## Best Practices Shown

- ✅ **Consistent Plugin Interface:** Same register() pattern across examples
- ✅ **Foundation Compatibility:** Adapter pattern bridges infrastructure
- ✅ **RBAC Integration:** Granular permissions throughout
- ✅ **Schema Consistency:** No tenantId columns in tenant schemas  
- ✅ **Error Handling:** Structured error responses
- ✅ **Logging:** Consistent logging patterns
- ✅ **Configuration:** Flexible settings per module

## Testing Integration

After integrating an example:

1. **Verify Discovery:** Module appears in foundation automatically
2. **Test API:** All endpoints accessible at `/api/plugins/{moduleId}/*`
3. **Check RBAC:** Permissions integrated into foundation system
4. **Test Navigation:** Module items appear in dashboard nav
5. **Validate Data:** CRUD operations work with proper tenant isolation

---

**Choose the example closest to your needs and customize from there!**