// Task management module configuration - advanced example
export default {
  id: 'tasks',
  name: 'Task Management',
  version: '1.0.0',
  api: '1.x',
  permissions: [
    // Task permissions
    'tasks.tasks.read',
    'tasks.tasks.create',
    'tasks.tasks.update',
    'tasks.tasks.delete',
    'tasks.tasks.assign',
    'tasks.tasks.complete',
    
    // Project permissions
    'tasks.projects.read',
    'tasks.projects.create',
    'tasks.projects.update',
    'tasks.projects.delete',
    
    // Team management
    'tasks.team.read',
    'tasks.team.manage',
    
    // Workflow permissions
    'tasks.workflows.read',
    'tasks.workflows.create',
    'tasks.workflows.update',
    
    // Reporting
    'tasks.reports.read',
    'tasks.reports.export',
    
    // Administrative
    'tasks.admin'
  ],
  nav: {
    basePath: '/app/tasks',
    items: [
      { 
        path: '/app/tasks/dashboard', 
        label: 'Dashboard', 
        icon: 'LayoutDashboard',
        permissions: ['tasks.tasks.read']
      },
      { 
        path: '/app/tasks/my-tasks', 
        label: 'My Tasks', 
        icon: 'CheckSquare',
        permissions: ['tasks.tasks.read']
      },
      { 
        path: '/app/tasks/projects', 
        label: 'Projects', 
        icon: 'Folder',
        permissions: ['tasks.projects.read']
      },
      { 
        path: '/app/tasks/team', 
        label: 'Team', 
        icon: 'Users',
        permissions: ['tasks.team.read']
      },
      { 
        path: '/app/tasks/workflows', 
        label: 'Workflows', 
        icon: 'GitBranch',
        permissions: ['tasks.workflows.read']
      },
      { 
        path: '/app/tasks/reports', 
        label: 'Reports', 
        icon: 'PieChart',
        permissions: ['tasks.reports.read']
      },
      {
        path: '/app/tasks/settings',
        label: 'Settings',
        icon: 'Settings',
        permissions: ['tasks.admin']
      }
    ]
  },
  settings: {
    enableNotifications: true,
    enableTimeTracking: true,
    enableSubtasks: true,
    enableAttachments: true,
    maxAttachmentSize: '25MB',
    defaultPageSize: 20,
    autoAssignEnabled: false,
    workflowsEnabled: true,
    ganttChartEnabled: true,
    kanbanBoardEnabled: true
  }
};