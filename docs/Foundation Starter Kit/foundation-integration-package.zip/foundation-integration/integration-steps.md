# Step-by-Step Foundation Integration Guide

This guide walks you through integrating a sandbox-developed plugin into the React Admin Foundation application.

## Prerequisites

- ✅ Working sandbox plugin with complete functionality
- ✅ Foundation application setup and running
- ✅ Understanding of plugin architecture and adapter pattern

## Step 1: Prepare Plugin for Integration

### 1.1 Validate Sandbox Plugin

Before integration, ensure your sandbox plugin is production-ready:

```bash
# In your sandbox project
npm run dev

# Test all functionality:
# - Health endpoint: GET /api/plugins/[module]/health → 200
# - CRUD operations work correctly
# - RBAC permissions enforced
# - Frontend UI complete
```

### 1.2 Document Plugin Interface

Create documentation for your plugin:

```typescript
// Document your plugin's API surface
interface YourModulePlugin {
  meta: {
    id: string;        // e.g., 'inventory'
    version: string;   // e.g., '1.0.0'
    api: string;       // e.g., '1.x'
  };
  register(ctx: PluginContext): Promise<void>;
}

// Document your permissions
const permissions = [
  'inventory.products.read',
  'inventory.products.create',
  'inventory.products.update',
  'inventory.products.delete',
  'inventory.categories.read',
  // ... list all permissions
];
```

## Step 2: Create Foundation Module Structure

### 2.1 Create Module Directory

```bash
# In your foundation project root
mkdir -p src/modules/your-module/{server/{routes},client}
mkdir -p src/modules/your-module/server/routes
```

Expected structure:
```
src/modules/your-module/
├── server/
│   ├── plugin.ts              # Your sandbox plugin code
│   └── routes/
│       └── index.ts           # Foundation adapter
├── client/                    # Frontend components
├── schema.ts                  # Database schema
└── module.config.ts           # Module configuration
```

### 2.2 Copy Plugin Files

```bash
# From sandbox to foundation
cp sandbox/server/index.ts foundation/src/modules/your-module/server/plugin.ts
cp sandbox/shared/schema.ts foundation/src/modules/your-module/schema.ts
cp -r sandbox/client/src/* foundation/src/modules/your-module/client/
```

## Step 3: Create Foundation Adapter

### 3.1 Create Route Adapter

Create `src/modules/your-module/server/routes/index.ts`:

```typescript
import { Router } from 'express';
import plugin, { permissions as pluginPermissions } from '../plugin';
import { withTenantTx } from '../../../lib/db/tenant-db';
import { requirePermission } from '../../../lib/security/rbac';

const router = Router();

// Create plugin context that bridges to foundation infrastructure
const ctx = {
  router,
  rbac: { 
    require: (perm: string) => requirePermission(perm) 
  },
  withTenantTx,
  log: (msg: string, meta?: object) =>
    console.log(JSON.stringify({ 
      at: 'plugin', 
      plugin: plugin.meta?.id ?? 'your-module', 
      msg, 
      ...meta 
    })),
};

// Register the plugin with foundation context
await plugin.register(ctx);

// Export for foundation system
export const permissions = pluginPermissions;
export default router;
```

### 3.2 Handle Async Registration

If the foundation doesn't support top-level await, use this pattern:

```typescript
import { Router } from 'express';
import plugin, { permissions as pluginPermissions } from '../plugin';
import { withTenantTx } from '../../../lib/db/tenant-db';
import { requirePermission } from '../../../lib/security/rbac';

const router = Router();
const ctx = {
  router,
  rbac: { require: (perm: string) => requirePermission(perm) },
  withTenantTx,
  log: (msg: string, meta?: object) => console.log(JSON.stringify({...}))
};

// Register plugin with error handling
plugin.register(ctx).catch(error => {
  console.error(`Failed to register plugin ${plugin.meta?.id}:`, error);
});

export const permissions = pluginPermissions;
export default router;
```

## Step 4: Add Module Configuration

### 4.1 Create Module Config

Create `src/modules/your-module/module.config.ts`:

```typescript
export default {
  id: 'your-module',                    // Must match plugin.meta.id
  name: 'Your Module Display Name',      // Human-readable name
  version: '1.0.0',                     // Version number
  api: '1.x',                          // API compatibility
  permissions: [
    'your-module.resource.read',
    'your-module.resource.create',
    'your-module.resource.update',
    'your-module.resource.delete',
    'your-module.admin',               // Administrative permissions
  ],
  nav: {
    basePath: '/app/your-module',        // Base URL path
    items: [
      {
        path: '/app/your-module/list',
        label: 'Items',
        icon: 'List',                    // Icon component name
        permissions: ['your-module.resource.read']
      },
      {
        path: '/app/your-module/create',
        label: 'Create Item',
        icon: 'Plus',
        permissions: ['your-module.resource.create']
      }
    ]
  },
  // Optional: module-specific settings
  settings: {
    enableBulkOperations: true,
    defaultPageSize: 25,
    maxFileUploadSize: '10MB'
  }
};
```

### 4.2 Integrate with Foundation Router Registry

Add to foundation's module registry (if manual registration required):

```typescript
// In foundation's module registry file
import yourModuleConfig from './modules/your-module/module.config';
import yourModuleRoutes from './modules/your-module/server/routes';

export const modules = [
  // ... existing modules
  {
    config: yourModuleConfig,
    routes: yourModuleRoutes,
  },
];
```

## Step 5: Database Schema Integration

### 5.1 Add Schema to Foundation

```typescript
// In foundation's main schema file or module-specific schema
export * from './modules/your-module/schema';

// Or if using separate schema files:
import { yourModuleSchema } from './modules/your-module/schema';
export { yourModuleSchema };
```

### 5.2 Run Database Migrations

```bash
# In foundation project
npm run db:push

# Or if force is needed (for schema changes)
npm run db:push --force
```

### 5.3 Verify Schema Creation

```sql
-- Check that tables were created in tenant schemas
\c your_foundation_db
SET search_path TO tenant_dev; -- or your dev tenant schema
\dt  -- Should show your module tables
```

## Step 6: Frontend Integration

### 6.1 Register Module Routes

Add module routes to foundation's router:

```typescript
// In foundation's main router configuration
import { lazy } from 'react';

const YourModuleRoutes = lazy(() => import('./modules/your-module/client/routes'));

export const moduleRoutes = [
  // ... existing routes
  {
    path: '/app/your-module/*',
    element: <YourModuleRoutes />,
    permissions: ['your-module.resource.read']
  }
];
```

### 6.2 Update Navigation

The foundation should automatically detect navigation from `module.config.ts`, but verify:

```typescript
// Navigation should show items from your module.config.ts nav section
// Check that navigation permissions are enforced correctly
```

## Step 7: Testing Integration

### 7.1 Start Foundation Application

```bash
# In foundation project
npm run dev

# Verify application starts without errors
# Check console for plugin registration messages
```

### 7.2 Test API Integration

```bash
# Health check
curl http://localhost:5000/api/plugins/your-module/health

# Test endpoints
curl -H "Authorization: Bearer YOUR_DEV_TOKEN" \
     http://localhost:5000/api/plugins/your-module/items

# Create test data
curl -X POST \
     -H "Authorization: Bearer YOUR_DEV_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"name":"Test Item"}' \n     http://localhost:5000/api/plugins/your-module/items
```

### 7.3 Test Frontend Integration

1. **Navigation:** Verify module appears in sidebar navigation
2. **Routing:** Test that module routes load correctly
3. **RBAC:** Verify permissions hide/show elements appropriately
4. **API Integration:** Test frontend can communicate with backend
5. **Error Handling:** Verify error states are handled gracefully

### 7.4 Test RBAC Integration

```typescript
// Test different permission combinations
// - Users with read-only access
// - Users with full CRUD permissions  
// - Users without module access
// - Administrative users
```

## Step 8: Production Deployment

### 8.1 Environment Configuration

```bash
# Ensure production environment variables are set
DATABASE_URL=postgresql://prod-connection
NODE_ENV=production

# Module-specific environment variables if needed
YOUR_MODULE_API_KEY=prod-api-key
YOUR_MODULE_CONFIG=production
```

### 8.2 Database Migration

```bash
# Run production database migration
NODE_ENV=production npm run db:push
```

### 8.3 Deployment Verification

1. **Health Checks:** All endpoints return 200 status
2. **Permissions:** RBAC system recognizes module permissions
3. **Navigation:** Module appears in production dashboard
4. **Data Isolation:** Tenant data properly isolated
5. **Performance:** Response times acceptable under load

## 🚨 Troubleshooting

### Plugin Not Discovered

**Symptoms:** Module doesn't appear in foundation, routes not accessible
**Solution:** 
1. Check `module.config.ts` exists and has proper exports
2. Verify foundation's module discovery mechanism
3. Check console for registration errors

### Route Registration Failures

**Symptoms:** 404 errors on module endpoints
**Solution:**
1. Verify adapter exports `default router`
2. Check plugin registration completes without errors
3. Ensure foundation mounts module routes correctly

### Permission Integration Issues

**Symptoms:** RBAC not working, access denied errors
**Solution:**
1. Check adapter uses foundation's `requirePermission`
2. Verify permissions exported from adapter
3. Ensure foundation RBAC system recognizes module permissions

### Database Schema Issues

**Symptoms:** Table not found, schema errors
**Solution:**
1. Verify schema files imported correctly
2. Check database migration completed successfully
3. Ensure tenant schemas contain module tables

### Frontend Integration Problems

**Symptoms:** Module pages not loading, navigation missing
**Solution:**
1. Check module routes registered in foundation router
2. Verify navigation configuration in `module.config.ts`
3. Ensure frontend build includes module components

## 📋 Integration Checklist

### Pre-Integration
- [ ] Sandbox plugin fully functional
- [ ] All tests passing in sandbox environment
- [ ] Plugin interface documented
- [ ] Database schema finalized

### Foundation Setup
- [ ] Module directory structure created
- [ ] Plugin files copied to foundation
- [ ] Adapter created and configured
- [ ] Module configuration defined

### Integration Testing
- [ ] Foundation starts without errors
- [ ] Plugin registration successful
- [ ] API endpoints accessible
- [ ] RBAC permissions working
- [ ] Frontend navigation functional

### Production Deployment
- [ ] Environment variables configured
- [ ] Database migration successful
- [ ] Health checks passing
- [ ] Performance validated
- [ ] Security review completed

---

**Integration Complete!** Your sandbox-developed plugin is now fully integrated into the React Admin Foundation application.