# Foundation Integration Package

This package contains examples and documentation for integrating sandbox-developed plugins into the main React Admin Foundation application.

## 📦 Package Contents

```
foundation-integration/
├── README.md                    # This file - integration guide
├── foundation-adapter/          # Adapter examples from sandbox
│   ├── module-config.ts         # Module configuration template
│   └── routes-index.ts          # Router adapter template
├── examples/                    # Complete integration examples
│   ├── inventory-integration/   # Full inventory module integration
│   ├── tasks-integration/       # Full tasks module integration
│   └── sample-integration/      # Basic sample module integration
└── integration-steps.md         # Step-by-step integration guide
```

## 🚀 Quick Integration Process

### 1. Copy Plugin from Sandbox

After developing your plugin in the sandbox environment:

```bash
# From your sandbox project directory:
cp server/index.ts ../foundation/src/modules/your-module/server/plugin.ts
cp shared/schema.ts ../foundation/src/modules/your-module/schema.ts
cp -r client/src/ ../foundation/src/client/modules/your-module/
```

### 2. Create Foundation Adapter

Use the template from `foundation-adapter/routes-index.ts`:

```typescript
// foundation: src/modules/your-module/server/routes/index.ts
import { Router } from 'express';
import plugin, { permissions as pluginPermissions } from '../../../server/plugin';
import { withTenantTx } from '../../../../lib/db/tenant-db';
import { requirePermission } from '../../../../lib/security/rbac';

const router = Router();
const ctx = {
  router,
  rbac: { require: (perm: string) => requirePermission(perm) },
  withTenantTx,
  log: (msg: string, meta?: object) => 
    console.log(JSON.stringify({ 
      at: 'plugin', 
      plugin: plugin.meta?.id ?? 'your-module', 
      msg, 
      ...meta 
    }))
};

await plugin.register(ctx);
export const permissions = pluginPermissions;
export default router;
```

### 3. Add Module Configuration

Use the template from `foundation-adapter/module-config.ts`:

```typescript
// foundation: src/modules/your-module/module.config.ts
export default {
  id: 'your-module',
  name: 'Your Module Name',
  version: '1.0.0',
  api: '1.x',
  permissions: [
    'your-module.resource.read',
    'your-module.resource.create',
    'your-module.resource.update', 
    'your-module.resource.delete',
  ],
  nav: {
    basePath: '/app/your-module',
    items: [
      { 
        path: '/app/your-module/list', 
        label: 'Items', 
        permissions: ['your-module.resource.read'] 
      }
    ]
  }
};
```

### 4. Foundation Auto-Discovery

The foundation automatically:
- ✅ Discovers modules in `src/modules/*/module.config.ts`
- ✅ Mounts routes at `/api/plugins/{moduleId}/*`
- ✅ Integrates permissions into RBAC system
- ✅ Adds navigation items to dashboard

## 🏗️ Architecture Pattern

### Sandbox → Foundation Bridge

The adapter pattern enables seamless integration:

**Sandbox (Development):**
```typescript
// Clean plugin authoring API
const plugin = {
  async register(ctx: PluginContext) {
    ctx.router.get('/items', ctx.rbac.require('perm'), handler);
  }
};
```

**Foundation (Production):**
```typescript
// Adapter bridges to foundation infrastructure
const ctx = {
  router: foundationRouter,
  rbac: { require: foundationRBAC },
  withTenantTx: foundationTenantHelper
};
await plugin.register(ctx); // Same plugin, different context!
```

### Key Benefits

- ✅ **Same Code:** Plugin logic unchanged between environments
- ✅ **Clean Separation:** Business logic isolated from infrastructure
- ✅ **Foundation Compatible:** Integrates with existing routing, RBAC, database
- ✅ **Type Safe:** Full TypeScript support throughout integration

## 🔧 Integration Examples

See the `examples/` directory for complete integration examples:

- **`sample-integration/`** - Basic plugin with simple CRUD operations
- **`inventory-integration/`** - Complex module with relationships and validation
- **`tasks-integration/`** - Advanced module with status management and workflows

Each example includes:
- Complete plugin code (`server/plugin.ts`)
- Foundation adapter (`server/routes/index.ts`) 
- Module configuration (`module.config.ts`)
- Database schema (`schema.ts`)
- Frontend components (`client/`)
- Integration testing checklist

## 📋 Integration Checklist

Before deploying your integrated module:

### Development Environment
- [ ] Plugin works in sandbox environment
- [ ] All CRUD operations tested and validated
- [ ] RBAC permissions working correctly
- [ ] Frontend UI complete and functional
- [ ] Database schema finalized

### Foundation Integration  
- [ ] Plugin files copied to foundation structure
- [ ] Adapter created using template pattern
- [ ] Module configuration defined with nav items
- [ ] Database schema added to foundation migrations
- [ ] Frontend components integrated

### Testing & Validation
- [ ] Foundation discovers module automatically
- [ ] Routes mounted at `/api/plugins/{moduleId}/*`
- [ ] Permissions integrated into RBAC system
- [ ] Navigation items appear in dashboard
- [ ] Full functionality works in foundation context

### Production Readiness
- [ ] Error handling comprehensive
- [ ] Logging and monitoring configured
- [ ] Performance optimizations applied
- [ ] Security review completed
- [ ] Documentation updated

## 🚨 Common Integration Issues

### Plugin Not Discovered

**Problem:** Foundation doesn't find your module
**Solution:** Ensure `module.config.ts` exists with proper export structure

### Route Mounting Failures

**Problem:** Routes not accessible at `/api/plugins/{moduleId}/*`
**Solution:** Verify adapter exports `default router` and `permissions`

### RBAC Integration Issues

**Problem:** Permissions not working in foundation
**Solution:** Check adapter uses foundation's `requirePermission` function

### Database Schema Conflicts

**Problem:** Schema conflicts between sandbox and foundation
**Solution:** Use same schema patterns - no `tenantId` in tenant tables

### Type Errors in Adapter

**Problem:** TypeScript errors in adapter code
**Solution:** Ensure foundation context matches plugin expectations

## 🔗 Related Documentation

- **Sandbox Setup:** `docs/module-sandbox-setup.md`
- **Architecture Guide:** Foundation schema-per-tenant patterns
- **RBAC Implementation:** Permission-based access control
- **Database Guidelines:** Schema design and migration patterns

---

**Ready to integrate your plugin?** Follow the step-by-step guide in `integration-steps.md` for detailed instructions!