# Module Sandbox Template

A turnkey development environment for creating business modules using clean plugin architecture.

## 🚀 Quick Start

1. **Install Dependencies:**
   ```bash
   npm install
   ```

2. **Configure Environment:**
   ```bash
   cp .env.example .env
   # Edit .env with your DATABASE_URL
   ```

3. **Initialize Database:**
   ```bash
   npm run db:push
   ```

4. **Start Development:**
   ```bash
   npm run dev
   ```

5. **Access Your Module:**
   - Frontend: http://localhost:5173
   - API Health: http://localhost:8787/api/plugins/sample/health

## 📁 Project Structure

```
├── server/index.ts         # 🎯 YOUR MAIN FOCUS - Plugin business logic
├── sandbox/               # Infrastructure (managed automatically)
│   ├── bootstrap.ts       # Database initialization
│   ├── rbac.ts           # Permission system
│   ├── server.ts         # Infrastructure server
│   └── withTenantTx.ts   # Database helpers
├── client/src/            # React frontend components
├── shared/schema.ts       # Database schema (no tenantId needed)
├── foundation-adapter/    # Foundation integration examples
├── vite.config.ts        # Vite proxy configuration
└── .env.example          # Environment variables template
```

## 🔧 Development Workflow

### 1. Customize Your Module
- **Module ID**: Update `MODULE_ID` in `server/index.ts`
- **Database Schema**: Add tables in `shared/schema.ts`
- **Business Logic**: Implement CRUD operations in `server/index.ts`
- **UI Components**: Customize `client/src/main.tsx`

### 2. Clean Plugin Pattern
```typescript
// server/index.ts - YOUR AUTHORING API
const plugin = {
  meta: { id: 'sample', version: '0.1.0', api: '1.x' },
  
  async register(ctx: PluginContext) {
    // Use ctx.router, ctx.rbac, ctx.withTenantTx, ctx.log
    ctx.router.get('/items', ctx.rbac.require('sample.items.read'), async (req: any, res) => {
      const rows = await ctx.withTenantTx(req.auth?.tenant_id, async (db) => {
        const r = await db.execute('select * from items order by created_at desc');
        return (r as any).rows ?? r;
      });
      res.json(rows);
    });
  },
};

export const permissions = ['sample.items.read', 'sample.items.create'];
export default plugin;
```

### 3. Schema-per-Tenant
```typescript
// shared/schema.ts - NO tenantId column needed
export const items = pgTable('items', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  name: varchar('name', { length: 255 }).notNull(),
  created_at: timestamp('created_at').defaultNow().notNull(),
});
```

## ✅ Verification Checklist

- [ ] `GET /api/plugins/sample/health` returns `200 { ok: true }`
- [ ] Database creates `tenant_dev` schema and `items` table automatically
- [ ] `GET /api/plugins/sample/items` returns `200` (with permissions)
- [ ] React frontend loads and can add/list items via API
- [ ] No `tenantId` columns in tenant schema tables
- [ ] CORS works for Vite proxy (no preflight errors)

## 🏗️ Foundation Integration

When ready, your plugin integrates seamlessly with the main foundation using the **adapter pattern**:

### Copy Plugin Files
```bash
cp server/index.ts ../foundation/src/modules/sample/server/plugin.ts
cp shared/schema.ts ../foundation/src/modules/sample/schema.ts
```

### Create Foundation Adapter
```typescript
// foundation: src/modules/sample/server/routes/index.ts
import { Router } from 'express';
import plugin, { permissions as pluginPermissions } from '../../../server/plugin';
import { withTenantTx } from '../../../../lib/db/tenant-db';
import { requirePermission } from '../../../../lib/security/rbac';

const router = Router();
const ctx = {
  router,
  rbac: { require: (perm: string) => requirePermission(perm) },
  withTenantTx,
  log: (msg, meta) => console.log(JSON.stringify({...}))
};

await plugin.register(ctx);
export const permissions = pluginPermissions;
export default router; // ← Foundation expects this
```

### Add Module Config
```typescript
// foundation: src/modules/sample/module.config.ts
export default {
  id: 'sample',
  name: 'Sample Module',
  version: '1.0.0',
  api: '1.x',
  permissions: ['sample.items.read', 'sample.items.create'],
  nav: { basePath: '/app/sample', items: [...] }
};
```

The foundation auto-discovers and mounts at `/api/plugins/sample/*`!

## 🎯 Key Features

- ✅ **Turnkey Setup** - Download, extract, `npm run dev`
- ✅ **Bootstrap Self-Sufficiency** - Creates all required database tables automatically
- ✅ **CORS Development** - Smooth Vite proxy integration 
- ✅ **Schema-per-Tenant** - Clean isolation without `tenantId` columns
- ✅ **Clean Plugin API** - Focus on business logic in `register(ctx)`
- ✅ **Foundation Compatible** - Same code works in both environments
- ✅ **Full RBAC Integration** - Permission-based access control

## 📖 Architecture Notes

- **System Tables**: Use `tenantId` columns (global scope)
- **Module Tables**: Use schema-per-tenant isolation (no `tenantId` needed)
- **Database Access**: Always via `ctx.withTenantTx()` - never direct clients
- **Permissions**: Declared with plugin, seeded automatically
- **Health Endpoint**: Always open at `/api/plugins/:id/health`

---

**Ready to build your module?** Start with `npm run dev` and focus on `server/index.ts`!